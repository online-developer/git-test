This directory is used as a default location in which Openfire stores backups of keystore files.
